pip install poetry
poetry new rci
